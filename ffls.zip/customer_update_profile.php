<?php
session_start();
include 'db_connection.php';

if (!isset($_SESSION['client_logged_in'], $_SESSION['client_username'])) {
    echo "<script>alert('Please log in to update your profile.'); window.location.href='customer_login.php';</script>";
    exit();
}

$clientUsername = mysqli_real_escape_string($conn, $_SESSION['client_username']);
$sqlUID = "SELECT customer_id FROM customer WHERE username='$clientUsername'";
$resUID = $conn->query($sqlUID);
if (!$resUID || $resUID->num_rows === 0) {
    echo "<script>alert('User not found. Please log in again.'); window.location.href='customer_login.php';</script>";
    exit();
}
$rowUID = $resUID->fetch_assoc();
$customer_id = $rowUID['customer_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name     = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name      = mysqli_real_escape_string($conn, $_POST['last_name']);
    $email          = mysqli_real_escape_string($conn, $_POST['email']);
    $newUsername    = mysqli_real_escape_string($conn, $_POST['username']);
    $contactNumber  = mysqli_real_escape_string($conn, $_POST['contact_number']);
    $street         = mysqli_real_escape_string($conn, $_POST['street']);
    $barangay       = mysqli_real_escape_string($conn, $_POST['barangay']);
    $city           = mysqli_real_escape_string($conn, $_POST['city']);

    $update = "UPDATE customer SET
        first_name='$first_name',
        last_name='$last_name',
        email='$email',
        username='$newUsername',
        contact_number='$contactNumber',
        street='$street',
        barangay='$barangay',
        city='$city'
        WHERE customer_id='$customer_id'";

    if ($conn->query($update)) {
        session_unset();
        session_destroy();
        echo "<script>
                alert('Profile updated successfully. Please log in again.');
                window.location.href='customer_login.php';
              </script>";
        exit();
    } else {
        echo "<script>
                alert('Error updating profile: " . addslashes($conn->error) . "');
                window.location.href='customer_dashboard.php';
              </script>";
        exit();
    }
}
?>
