<?php
session_start();
include('db_connection.php');

$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']); // no hashing

    // Check if username already exists
    $check_username_sql = "SELECT username FROM admin WHERE username = '$username'";
    $check_username_result = mysqli_query($conn, $check_username_sql);

    if (mysqli_num_rows($check_username_result) > 0) {
        $error = 'Username already exists. Please choose a different username.';
    } else {
        $insert_admin = "INSERT INTO admin (username, password) VALUES ('$username', '$password')";

        if (mysqli_query($conn, $insert_admin)) {
            $success = true;
            $message = 'Admin account created successfully! You will now be redirected to the login page.';
            header("refresh:3;url=admin_login.php");
            exit();
        } else {
            $error = 'Error creating admin account: ' . mysqli_error($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Sign Up</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            min-height: 100vh;
            overflow: auto;
            flex-wrap: wrap;
        }

        .left-side {
            flex: 1;
            background: url('FFLSbg.jpg') no-repeat center center/cover;
        }

        .right-side {
            flex: 1;
            max-width: 500px;
            background-color: #d1e3ff;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            overflow-y: auto;
        }

        .logo {
            width: 230px;
            margin: 20px 0;
            align-self: center;
        }

        .input-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 350px;
            text-align: left;
        }

        .input-container label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
        }

        .input-container input {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-footer {
            display: flex;
            justify-content: flex-end;
            margin-top: 10px;
        }

        .signup {
            background-color: #6a9ff8;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 14px;
            cursor: pointer;
        }

        .link-back-login {
            text-align: right;
            margin-top: 10px;
            font-size: 14px;
        }

        .link-back-login a {
            color: #6a9ff8;
            text-decoration: none;
        }

        .link-back-login a:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            body {
                flex-direction: column;
            }

            .left-side {
                display: none;
            }

            .right-side {
                width: 100%;
                max-width: none;
            }

            .logo {
                align-self: center;
            }

            .form-footer {
                justify-content: flex-end;
            }
        }
    </style>
</head>
<body>
<div class="left-side"></div>
<div class="right-side">
    <img src="FFLSlogo.png" class="logo" alt="Logo">
    <div class="input-container">
        <h2>Admin Sign Up</h2>
        <?php if ($error): ?>
            <p style="color:red; margin-bottom:10px;"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>
        <?php if ($success): ?>
            <p style="color:green; margin-bottom:10px;"><?php echo htmlspecialchars($message); ?></p>
            <p class="link-back-login"><a href="admin_login.php">Back to Admin Login</a></p>
        <?php else: ?>
            <form method="POST" action="">
                <label for="username">Username:</label>
                <input type="text" name="username" required>

                <label for="password">Password:</label>
                <input type="password" name="password" required>

                <div class="form-footer">
                    <button class="signup" type="submit">Sign Up</button>
                </div>

                <p class="link-back-login"><a href="admin_login.php">Back to Admin Login</a></p>
            </form>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
