<?php
require 'db_connection.php'; // Adjust this path if needed

header('Content-Type: application/json');

// Check if the laundry_request_id is set
if (isset($_POST['laundry_request_id'])) {
    $laundryRequestId = intval($_POST['laundry_request_id']);

    // Prepare the DELETE query
    $stmt = $conn->prepare("DELETE FROM laundry_request WHERE laundry_request_id = ?");
    $stmt->bind_param("i", $laundryRequestId);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Error deleting record: ' . $stmt->error
        ]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Missing laundry_request_id.'
    ]);
}
?>
