<?php
session_start();
include('db_connection.php');

$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $middle_name = mysqli_real_escape_string($conn, $_POST['middle_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $contact_number = mysqli_real_escape_string($conn, $_POST['contact_number']);
    $street = mysqli_real_escape_string($conn, $_POST['street']);
    $barangay = mysqli_real_escape_string($conn, $_POST['barangay']);
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    $province = mysqli_real_escape_string($conn, $_POST['province']);
    $zip_code = mysqli_real_escape_string($conn, $_POST['zip_code']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $insert_customer = "INSERT INTO customer (first_name, middle_name, last_name, contact_number, street, barangay, city, province, zip_code, email, username, password) 
                        VALUES ('$first_name', '$middle_name', '$last_name', '$contact_number', '$street', '$barangay', '$city', '$province', '$zip_code', '$email', '$username', '$password')";

    if (mysqli_query($conn, $insert_customer)) {
        $success = true;
        $message = 'Customer account created successfully! You can now log in.';
    } else {
        $error = 'Error creating customer account: ' . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Sign Up</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            min-height: 100vh;
            overflow: auto;
            flex-wrap: wrap;
        }

        .left-side {
            flex: 1;
            background: url('FFLSbg.jpg') no-repeat center center/cover;
        }

        .right-side {
            flex: 1;
            max-width: 500px;
            background-color: #d1e3ff;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            overflow-y: auto;
        }

        .logo {
            width: 230px;
            margin: 20px 0;
        }

        .input-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 350px;
            text-align: left;
        }

        .input-container label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
        }

        .input-container input {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .buttons {
            display: flex;
            justify-content: flex-end; /* Aligns both buttons to the right */
            gap: 10px; /* Adds space between the buttons */
        }

        .buttons button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            text-align: center;
        }

        .signup {
            background-color: #6a9ff8;
            color: white;
        }

        .back-login {
            background-color: white;
            border: 1px solid #6a9ff8;
            color: #6a9ff8;
        }

        .back-login:hover {
            background-color: #6a9ff8;
            color: white;
        }

        @media (max-width: 768px) {
            body {
                flex-direction: column;
            }

            .left-side {
                display: none;
            }

            .right-side {
                width: 100%;
                max-width: none;
            }
        }
    </style>
</head>
<body>
<div class="left-side"></div>
<div class="right-side">
    <img src="FFLSlogo.png" class="logo" alt="Logo">
    <div class="input-container">
        <h2>Customer Sign Up</h2>
        <?php if ($error): ?>
            <p style="color:red; margin-bottom:10px;"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>
        <?php if ($success): ?>
            <p style="color:green; margin-bottom:10px;"><?php echo htmlspecialchars($message); ?></p>
            <div class="buttons">
                <button class="back-login" onclick="window.location.href='customer_login.php'">Go to Customer Login</button>
            </div>
        <?php else: ?>
            <form method="POST" action="">
                <label for="first_name">First Name:</label>
                <input type="text" name="first_name" required>

                <label for="middle_name">Middle Name:</label>
                <input type="text" name="middle_name">

                <label for="last_name">Last Name:</label>
                <input type="text" name="last_name" required>

                <label for="contact_number">Contact Number:</label>
                <input type="text" name="contact_number" required>

                <label for="street">Street:</label>
                <input type="text" name="street">

                <label for="barangay">Barangay:</label>
                <input type="text" name="barangay">

                <label for="city">City:</label>
                <input type="text" name="city">

                <label for="province">Province:</label>
                <input type="text" name="province">

                <label for="zip_code">Zip Code:</label>
                <input type="text" name="zip_code">

                <label for="email">Email:</label>
                <input type="email" name="email" required>

                <label for="username">Username:</label>
                <input type="text" name="username" required>

                <label for="password">Password:</label>
                <input type="password" name="password" required>

                <div class="buttons">
                    <button class="signup" type="submit">Sign Up</button>
                    <button class="back-login" onclick="window.location.href='customer_login.php'">Back to Customer Login</button>
                </div>
            </form>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
