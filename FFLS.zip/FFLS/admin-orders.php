<?php
session_start();
include('db_connection.php');

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

$adminUsername = $_SESSION['admin_username'];

// Function to fetch all orders
function getAllOrders($conn) {
    $sql = "SELECT lr.laundry_request_id AS order_id,
                    c.customer_id,
                    c.first_name,
                    c.last_name,
                    lr.date_placed AS order_date,
                    lr.total_price AS total_amount,
                    lr.status,
                    lr.wash_type
            FROM laundry_request lr
            JOIN customer c ON lr.customer_id = c.customer_id
            ORDER BY lr.date_placed DESC";
    $result = $conn->query($sql);
    $orders = [];
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $orders[] = $row;
        }
    }
    return $orders;
}

// Function to update order status
if (isset($_POST['update_status']) && isset($_POST['order_id']) && isset($_POST['new_status'])) {
    $orderId = intval($_POST['order_id']);
    $newStatus = mysqli_real_escape_string($conn, $_POST['new_status']);

    $updateSql = "UPDATE laundry_request SET status = ? WHERE laundry_request_id = ?";
    $updateStmt = $conn->prepare($updateSql);
    if ($updateStmt) {
        $updateStmt->bind_param("si", $newStatus, $orderId);
        if ($updateStmt->execute()) {
            echo "success"; // Indicate successful update
        } else {
            echo "error: " . $updateStmt->error;
        }
        $updateStmt->close();
    } else {
        echo "error: " . $conn->error;
    }
    exit(); // Stop further execution after processing the update
}

$orders = getAllOrders($conn);

// Fetch available add-ons (Liquid Detergent and Fabric Conditioner)
$addonsSql = "SELECT item_id, item_name, price
              FROM inventory
              WHERE category = 'Cleaning Supplies'
                AND (item_name LIKE '%Liquid Detergent%' OR item_name LIKE '%Fabric Conditioner%')
                AND quantity > 0
              ORDER BY item_name";
$addonsResult = $conn->query($addonsSql);
$addons = [];
if ($addonsResult && $addonsResult->num_rows > 0) {
    while ($row = $addonsResult->fetch_assoc()) {
        $addons[] = $row;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Orders - FreshFold Laundry Services</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <style>
        /* --- Reset and General Styles --- */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
            text-decoration: none;
        }

        body {
            background: #f8f9fa;
            display: flex;
            flex-direction: column;
            height: 100vh;
            overflow-x: auto; /* Added for potential horizontal scroll on smaller screens */
        }

        header {
            background: #82b8ef;
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
            height: 60px;
        }

        .logo-menu {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        #menu-btn {
            background: none;
            border: none;
            cursor: pointer;
            color: white;
            font-size: 20px;
        }

        #menu-btn img {
            width: 25px;
            height: 25px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 5px;
            position: relative;
        }

        .user-profile img {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .user-profile span {
            font-size: 14px;
        }

        .sidebar {
            background: #96c7f9;
            width: 240px;
            height: 100vh;
            position: fixed;
            left: -240px;
            top: 60px;
            padding-top: 10px;
            border-right: 1px solid #ccc;
            transition: left 0.3s ease-in-out;
            overflow-y: auto;
        }

        .sidebar.active {
            left: 0;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
        }

        .sidebar ul li img {
            width: 24px;
            height: 24px;
        }

        .sidebar ul li a {
            color: white;
            font-size: 16px;
        }

        .content {
            margin-left: 20px;
            margin-top: 80px;
            padding: 20px;
            transition: margin-left 0.3s ease-in-out;
            overflow-y: auto;
            height: calc(100vh - 80px);
        }

        .content.shift {
            margin-left: 260px;
        }

        h1 {
            margin-bottom: 20px;
            color: #333;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        h1 button {
            background-color: #96c7f9; /* Changed to blue */
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        h1 button:hover {
            background-color: #82b8ef; /* Slightly darker blue on hover */
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #96c7f9;
            font-weight: bold;
            color: white;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        .action-links {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .action-link {
            color: #82b8ef;
            cursor: pointer;
        }

        .action-link.delete {
            color: #f44336;
        }

        .action-link:hover {
            text-decoration: underline;
        }

        .status-select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            background-color: white;
        }

        .logout-box {
            position: absolute;
            top: 30px;
            right: 0;
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 5px;
            display: none;
            z-index: 1001;
        }

        .logout-box a {
            display: block;
            padding: 10px 20px;
            color: #165a91;
            text-decoration: none;
            font-size: 14px;
        }

        .logout-box a:hover {
            background-color: #f0f0f0;
        }

        /* Bootstrap Modal Styles (Override if needed) */
        .modal-dialog {
            margin: 1.75rem auto; /* Adjust for centering */
            max-width: 800px; /* Adjust as needed */
        }

        .modal-content {
            border-radius: 0.3rem;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 1.5rem;
            border-bottom: 1px solid #dee2e6;
            border-top-left-radius: 0.3rem;
            border-top-right-radius: 0.3rem;
        }

        .modal-title {
            margin-bottom: 0;
            line-height: 1.5;
            font-size: 1.25rem;
            font-weight: 500;
        }

        .btn-close {
            padding: 0.5rem 0.5rem;
            margin: -0.5rem -0.5rem -0.5rem auto;
            font-size: 1.5rem;
            font-weight: 700;
            line-height: 1;
            color: #000;
            text-shadow: 0 1px 0 #fff;
            opacity: .5;
            background-color: transparent;
            border: 0;
            border-radius: 0.3rem;
        }

        .btn-close:hover {
            opacity: .75;
        }

        .modal-body {
            padding: 1rem 1.5rem;
        }

        .modal-footer {
            display: flex;
            justify-content: flex-end;
            padding: 1rem 1.5rem;
            border-top: 1px solid #dee2e6;
            border-bottom-right-radius: 0.3rem;
            border-bottom-left-radius: 0.3rem;
        }

        .form-label {
            margin-bottom: 0.5rem;
            font-weight: bold;
        }

        .form-control {
            display: block;
            width: 100%;
            padding: 0.375rem 0.75rem;
            font-size: 1rem;
            font-weight: 400;
            line-height: 1.5;
            color: #212529;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid #ced4da;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            border-radius: 0.25rem;
            transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
            margin-bottom: 1rem;
        }

        .form-select {
            width: 100%;
            padding: 0.375rem 2.25rem 0.375rem 0.75rem;
            -moz-padding-start: calc(0.75rem - 3px);
            font-size: 1rem;
            font-weight: 400;
            line-height: 1.5;
            color: #212529;
            background-color: #fff;
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 0.75rem center;
            background-size: 16px 12px;
            border: 1px solid #ced4da;
            border-radius: 0.25rem;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            margin-bottom: 1rem;
        }

        .form-check {
            margin-bottom: 0.5rem;
        }

        .form-check-input {
            width: 1em;
            height: 1em;
            margin-top: 0.25em;
            vertical-align: top;
            background-color: #fff;
            background-repeat: no-repeat;
            background-position: center;
            background-size: contain;
            border: 1px solid rgba(0,0,0,.25);
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            -webkit-print-color-adjust: exact;
            color-adjust: exact;
        }

        .form-check-input[type=checkbox] {
            border-radius: 0.25em;
        }

        .form-check-input:checked {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }

        .form-check-input:focus {
            border-color: #86b7fe;
            outline: 0;
            box-shadow: 0 0 0 0.25rem rgba(13,110,253,.25);
        }

        .form-check-label {
            margin-left: 0.5em;
        }

        #addOrderModal {
            display: none; /* Ensure the modal is hidden by default */
        }

        .status-text {
            display: inline-block;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            background-color: #f9f9f9;
            min-width: 120px;
            text-align: center;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: #fff;
            margin: 10% auto;
            padding: 20px;
            width: 60%;
            border-radius: 10px;
        }
    </style>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <header>
        <div class="logo-menu">
            <img src="FFLSlogo.png" alt="Logo" style="height: 40px;">
            <button id="menu-btn">
                <img src="m-icon.png" alt="Menu">
            </button>
        </div>
        <div class="user-profile" id="logout-btn">
            <span>Admin</span>
            <img src="ad-icon.png" alt="Admin Icon">
            <div class="logout-box"id="logout-box">
                <a href="admin_login.php">Logout</a>
            </div>
        </div>
    </header>
    <div class="sidebar" id="sidebar">
        <ul>
            <li><a href="admin-dashboard.php"><img src="d-icon.png"></i> Dashboard</a></li>
            <li><a href="admin-orders.php" class="active"><img src="o-icon.png"></i> Orders</a></li>
            <li><a href="admin-customers.php"><img src="c-icon.png"></i> Customers</a></li>
            <li><a href="admin-inventory.php"><img src="i-icon.png"></i> Inventory</a></li>
            <li><a href="admin-Paymentsss.php"><img src="p-icon.png"></i> Payments</a></li>
            <li><a href="admin-reports.php"><img src="rp-icon.png"></i> Reports</a></li>
        </ul>
    </div>

    <div class="content" id="mainContent">
        <h1>
            Orders
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addOrderModal">Add New Order</button>
        </h1>

        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($_GET['success']); ?></div>
        <?php endif; ?>
        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($_GET['error']); ?></div>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer ID</th>
                    <th>Customer Name</th>
                    <th>Date Placed</th>
                    <th>Wash Type</th>
                    <th>Total Price</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($orders)): ?>
                    <tr><td colspan='8'>No orders found.</td></tr>
                <?php else: ?>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?php echo htmlspecialchars(sprintf('%04d', $order['order_id'])); ?></td>
                            <td><?php echo htmlspecialchars(sprintf('%03d', $order['customer_id'])); ?></td>
                            <td><?php echo htmlspecialchars($order['first_name'] . ' ' . $order['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($order['order_date']); ?></td>
                            <td><?php echo htmlspecialchars($order['wash_type']); ?></td>
                            <td>₱<?php echo htmlspecialchars(number_format($order['total_amount'], 2)); ?></td>
                            
                            <td>
                                <?php
                                    $status = htmlspecialchars($order['status']);
                                    $statusColor = '';

                                    switch (strtolower($status)) {
                                        case 'pending':
                                            $statusColor = 'color: #f1c40f; font-weight: bold;'; // Yellow
                                            break;
                                        case 'washing':
                                            $statusColor = 'color: #f39c12; font-weight: bold;'; // Deeper yellow
                                            break;
                                        case 'drying':
                                            $statusColor = 'color: #e67e22; font-weight: bold;'; // Orange
                                            break;
                                        case 'folding':
                                            $statusColor = 'color: #f39c12; font-weight: bold;'; // Yellow again
                                            break;
                                        case 'ready for pick up':
                                            $statusColor = 'color: #0077b6; font-weight: bold;'; // Blue
                                            break;
                                        case 'completed':
                                            $statusColor = 'color: #27ae60; font-weight: bold;'; // Green
                                            break;
                                        default:
                                            $statusColor = 'color: #333; font-weight: bold;';
                                    }
                                    echo "<span style='$statusColor'>$status</span>";
                                ?>
                            </td>


                            <td>
                                <div class="action-links">
                                    <span class='action-link' onclick='viewOrderDetails(<?php echo htmlspecialchars($order["order_id"]); ?>)'>View Details</span>
                                    <span class='action-link' onclick='editOrder(<?php echo htmlspecialchars($order['order_id']); ?>)'>Edit</span>
                                    <span class="action-link delete-btn" data-id="<?= htmlspecialchars($order['order_id']) ?>" style="color: red;">Delete</span>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="modal fade" id="addOrderModal" tabindex="-1" aria-labelledby="addOrderModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addOrderModalLabel">Add New Order</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="addOrderForm" action="process_new_order.php" method="post">
                            <div class="mb-3">
                                <label for="customer_name" class="form-label">Customer Name:</label>
                                <input type="text" class="form-control" id="customer_name" name="customer_name" placeholder="Enter Customer Name" required>
                            </div>
                            <div class="mb-3">
                                <label for="wash_type" class="form-label">Wash Type:</label>
                                <select class="form-select" id="wash_type" name="wash_type">
                                    <option value="Wash Only">Wash Only (₱50 per 8 kg)</option>
                                    <option value="Full Service">Full Service (Wash, Dry, Fold - ₱180 per 8 kg)</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="weight" class="form-label">Weight (kg):</label>
                                <input type="number" class="form-control" id="weight" name="weight" placeholder="Enter weight in kg" min="0" step="0.01">
                            </div>
                            <div class="mb-3">
                                <label for="status" class="form-label">Status:</label>
                                <select class="form-select" id="status_add" name="status">
                                    <option value="Pending">Pending</option>
                                    <option value="Washing">Washing</option>
                                    <option value="Drying">Drying</option>
                                    <option value="Folding">Folding</option>
                                    <option value="Ready for Pick-up">Ready for Pick-up</option>
                                    <option value="Completed">Completed</option>
                                    <option value="Cancelled">Cancelled</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="date_placed" class="form-label">Date Placed:</label>
                                <input type="text" class="form-control datepicker" id="date_placed" name="date_placed" placeholder="dd/mm/yyyy">
                            </div>
                            <div>
                                <label class="form-label">Add-ons (Select up to 3):</label><br>
                                <?php if (!empty($addons)): ?>
                                    <?php foreach ($addons as $addon): ?>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="addons[]" value="<?php echo htmlspecialchars($addon['item_id']); ?>" data-price="<?php echo htmlspecialchars($addon['price']); ?>" id="addon_<?php echo htmlspecialchars($addon['item_id']); ?>">
                                            <label class="form-check-label" for="addon_<?php echo htmlspecialchars($addon['item_id']); ?>">
                                                <?php echo htmlspecialchars($addon['item_name'] . ' (₱' . number_format($addon['price'], 2) . ')'); ?>
                                            </label>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p>No add-ons available in inventory.</p>
                                <?php endif; ?>
                            </div>
                            <p class="mt-3"><b>Total Payment: ₱<span id="total_payment">0.00</span></b></p>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary">Save Order</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="order-details-modal" tabindex="-1" aria-labelledby="orderDetailsModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="orderDetailsModalLabel">Order Details</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" id="order-details-content">
                        </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <script>
function viewOrderDetails(laundryRequestId) {
    $.ajax({
        url: 'view_order.php?laundry_request_id=' + laundryRequestId,
        method: 'GET',
        dataType: 'html',
        success: function (response) {
            // ✅ Load the response HTML into your modal body
            document.getElementById('order-details-content').innerHTML = response;

            // ✅ Show the modal using Bootstrap 5's JS API
            const modal = new bootstrap.Modal(document.getElementById('order-details-modal'));
            modal.show();
        },
        error: function (xhr, status, error) {
            alert('AJAX Error: ' + error + "\n" + xhr.responseText);
        }
    });
}

function getSubStatus(currentStatus, step) {
    const stages = ['Washing', 'Drying', 'Folding', 'Ready for Pick Up', 'Completed'];
    const currentIndex = stages.indexOf(currentStatus);
    const stepIndex = stages.indexOf(step);

    if (currentStatus === step) {
        return 'In Progress';
    } else if (currentIndex > stepIndex) {
        return 'Done';
    } else {
        return 'Pending';
    }
}


        function editOrder(laundryRequestId) {
            window.location.href = 'edit_order.php?laundry_request_id=' + laundryRequestId; // Updated to laundry_request_id
        }

        document.querySelectorAll('.delete-btn').forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();

                const laundryRequestId = this.getAttribute('data-id'); // Updated to laundry_request_id
                const row = this.closest('tr');

                if (confirm("Are you sure you want to delete this order?")) {
                    fetch('delete_order.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: 'laundry_request_id=' + encodeURIComponent(laundryRequestId) // Updated to laundry_request_id
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            row.remove();
                        } else {
                            alert("Failed to delete the order. " + (data.message || ""));
                        }
                    })
                    .catch(error => {
                        console.error("Error:", error);
                        alert("An error occurred.");
                    });
                }
            });
        });

        document.addEventListener('DOMContentLoaded', function() {
            const addOrderModalElement = document.getElementById('addOrderModal');
            const addOrderModal = new bootstrap.Modal(addOrderModalElement);
            const orderDetailsModalElement = document.getElementById('order-details-modal');
            const orderDetailsModal = new bootstrap.Modal(orderDetailsModalElement);

            document.getElementById('menu-btn').addEventListener('click', function() {
                document.getElementById('sidebar').classList.toggle('active');
                document.getElementById('mainContent').classList.toggle('shift');
            });

            document.getElementById('logout-btn').addEventListener('click', function() {
                document.getElementById('logout-box').style.display =
                    document.getElementById('logout-box').style.display === 'block' ? 'none' : 'block';
            });

            flatpickr(".datepicker", {
                dateFormat: "d/m/Y",
            });

            $(document).ready(function() {
                // Function to calculate total payment for Add New Order modal
                function calculateTotalPayment() {
                    const weight = parseFloat($('#weight').val());
                    if (isNaN(weight) || weight <= 0) {
                        $('#total_payment').text('0.00');
                        return;
                    }

                    if (washType === 'Wash Only') {
                        basePrice = Math.ceil(weight / 8) * 50;
                    } else if (washType === 'Full Service') {
                        basePrice = Math.ceil(weight / 8) * 180;
                    }

                    // Calculate add-on costs
                    $('input[name="addons[]"]:checked').each(function() {
                        addonCost += parseFloat($(this).data('price'));
                    });

                    const totalPayment = basePrice + addonCost;
                    $('#total_payment').text(totalPayment.toFixed(2));
                }

                // Event listeners for changes that affect total payment in Add New Order modal
                $('#wash_type, #weight, input[name="addons[]"]').on('change', calculateTotalPayment);

                // Limit add-on selections to 3 in Add New Order modal
                $(document).on('change', 'input[name="addons[]"]', function() {
                    const maxAddons = 3;
                    if ($('input[name="addons[]"]:checked').length > maxAddons) {
                        this.checked = false;
                        alert('You can select a maximum of ' + maxAddons + ' add-ons.');
                    }
                    calculateTotalPayment();
                });

                // Update order status via AJAX
                $('.status-select').on('change', function() {
                    const laundryRequestId = $(this).data('laundry-request-id'); // Updated to laundry_request_id
                    const newStatus = $(this).val();
                    const selectElement = $(this); // Store the select element
                    const statusCell = $('#status-cell-' + laundryRequestId); // Get the parent cell

                    $.post('admin-orders.php', { update_status: true, laundry_request_id: laundryRequestId, new_status: newStatus }, function(response) {
                        if (response === 'success') {
                            console.log('Status updated successfully for Laundry Request ID: ' + laundryRequestId + ' to ' + newStatus);
                            // Replace the select element with the updated status text
                            statusCell.html('<span class="status-text">' + newStatus + '</span>');
                        } else {
                            console.error('Error updating status for Laundry Request ID: ' + laundryRequestId + ': ' + response);
                        }
                    }).fail(function() {
                        console.error('AJAX request failed.');
                    });
                });
            });
        });
        </script>
    </div>
</body>
</html>