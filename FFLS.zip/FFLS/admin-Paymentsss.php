<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FreshFold Laundry - Payments</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
            text-decoration: none;
        }

        body {
            background: #f8f9fa;
            display: flex;
            flex-direction: column;
            height: 100vh;
            overflow: hidden;
        }

        header {
            background: #82b8ef;
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
            height: 60px;
        }

        .logo-menu {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        #menu-btn {
            background: none;
            border: none;
            cursor: pointer;
        }

        #menu-btn img {
            width: 25px;
            height: 25px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 5px;
            position: relative;
        }

        .user-profile img {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .user-profile span {
            font-size: 14px;
        }

        .logout-box {
            position: absolute;
            top: 30px;
            right: 0;
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 5px;
            display: none;
            z-index: 1001;
        }

        .logout-box a {
            display: block;
            padding: 10px 20px;
            color: #165a91;
            font-size: 14px;
        }

        .logout-box a:hover {
            background-color: #f0f0f0;
        }

        .sidebar {
            background: #96c7f9;
            width: 240px;
            height: 100vh;
            position: fixed;
            left: -240px;
            top: 60px;
            padding-top: 10px;
            transition: left 0.3s ease-in-out;
            z-index: 999;
        }

        .sidebar.active {
            left: 0;
        }

        .sidebar ul {
            list-style: none;
        }

        .sidebar ul li {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
        }

        .sidebar ul li img {
            width: 24px;
            height: 24px;
        }

        .sidebar ul li a {
            color: white;
            font-size: 16px;
        }

        .main-content {
            margin-top: 60px;
            padding: 20px;
            margin-left: 0;
            transition: margin-left 0.3s ease-in-out;
        }

        .main-content.shift {
            margin-left: 260px;
        }

        h1 {
            margin-bottom: 20px;
            color: #333;
        }

        .search-bar {
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
        }

        .search-bar input {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            flex: 1;
            max-width: 300px;
        }

        .search-bar button {
            padding: 8px 15px;
            background-color: #82b8ef;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        .status-pending { color: #ffc107; font-weight: bold; }
        .status-completed { color: #28a745; font-weight: bold; }
        .status-cancelled { color: #dc3545; font-weight: bold; }

        .no-results {
            padding: 20px;
            text-align: center;
            color: #666;
            font-style: italic;
            display: none;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo-menu">
            <img src="FFLSlogo.png" alt="FreshFold Logo" style="height: 50px;">
            <button id="menu-btn"><img src="m-icon.png" alt="Menu"></button>
        </div>
        <div class="user-profile" id="logout-btn">
            <span>Admin</span>
            <img src="ad-icon.png" alt="User Icon" id="profile-icon">
            <div class="logout-box" id="logout-box">
                <a href="login.html">Logout</a>
            </div>
        </div>
    </header>

    <div class="sidebar" id="sidebar">
        <ul>
            <li><img src="d-icon.png" alt="Dashboard"><a href="admin-dashboard.html">Dashboard</a></li>
            <li><img src="O-icon.png" alt="Orders"><a href="admin-orders.html">Orders</a></li>
            <li><img src="c-icon.png" alt="Customers"><a href="admin-customers.html">Customers</a></li>
            <li><img src="i-icon.png" alt="Inventory"><a href="admin-inventory.html">Inventory</a></li>
            <li><img src="p-icon.png" alt="Payments"><a href="admin-payments.html">Payments</a></li>
            <li><img src="rp-icon.png" alt="Reports"><a href="admin-reports.html">Reports</a></li>
        </ul>
    </div>

    <div class="main-content" id="mainContent">
        <h1>Payments</h1>
        <div class="search-bar">
            <input type="text" id="searchInput" placeholder="Search by customer name" onkeyup="searchPayments()">
            <button onclick="searchPayments()"><i class="fas fa-search"></i> Search</button>
        </div>
        
        <table id="paymentsTable">
            <thead>
                <tr>
                    <th>Payment ID</th>
                    <th>Order #</th>
                    <th>Customer Name</th>
                    <th>Payment Date</th>
                    <th>Amount Paid</th>
                    <th>Payment Method</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody id="paymentsTableBody">
                <tr><td>P1</td><td>001</td><td>Jamie Tan</td><td>03/20/25</td><td>₱300</td><td>Cash</td><td class="status-completed">Completed</td></tr>
                <tr><td>P2</td><td>002</td><td>Jay Xyz</td><td>03/30/25</td><td>₱500</td><td>Cash</td><td class="status-pending">Pending</td></tr>
                <tr><td>P3</td><td>003</td><td>Alex Girl</td><td>04/01/25</td><td>₱250</td><td>Cash</td><td class="status-completed">Completed</td></tr>
                <tr><td>P4</td><td>004</td><td>Maria Girl</td><td>04/02/25</td><td>₱180</td><td>Cash</td><td class="status-completed">Completed</td></tr>
                <tr><td>P5</td><td>005</td><td>Sam Boy</td><td>04/05/25</td><td>₱420</td><td>Cash</td><td class="status-pending">Pending</td></tr>
            </tbody>
        </table>
        <div id="noResults" class="no-results">No payments found matching your search.</div>
    </div>

    <script>
        
        document.getElementById('menu-btn').onclick = function () {
            document.getElementById('sidebar').classList.toggle('active');
            document.getElementById('mainContent').classList.toggle('shift');
        };

        
        const logoutBtn = document.getElementById('logout-btn');
        const logoutBox = document.getElementById('logout-box');
        const profileIcon = document.getElementById('profile-icon');

        logoutBtn.addEventListener('click', () => {
            logoutBox.style.display = logoutBox.style.display === 'block' ? 'none' : 'block';
        });

        
        function searchPayments() {
            const filter = document.getElementById('searchInput').value.toLowerCase();
            const rows = document.querySelectorAll('#paymentsTableBody tr');
            const noResults = document.getElementById('noResults');

            let found = false;
            rows.forEach(row => {
                const name = row.cells[2].textContent.toLowerCase();
                if (name.includes(filter)) {
                    row.style.display = '';
                    found = true;
                } else {
                    row.style.display = 'none';
                }
            });

            noResults.style.display = found ? 'none' : 'block';
        }
    </script>
</body>
</html>
