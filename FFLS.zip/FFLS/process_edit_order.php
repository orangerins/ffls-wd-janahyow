<?php
session_start();
include('db_connection.php');

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['laundry_request_id'])) {
        die("Invalid request: Missing ID.");
    }

    $id = intval($_POST['laundry_request_id']);
    $washType = $_POST['wash_type'];
    $weight = floatval($_POST['weight']);
    $status = $_POST['status'];
    $datePlaced = $_POST['date_placed'];

    if (empty($washType) || empty($weight) || empty($status)) {
        die("All fields are required.");
    }

    $sql = "UPDATE laundry_request 
            SET wash_type = ?, weight = ?, status = ?, date_placed = ? 
            WHERE laundry_request_id = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Error preparing statement.");
    }

    $stmt->bind_param("sdssi", $washType, $weight, $status, $datePlaced, $id);

    if ($stmt->execute()) {
        header("Location: admin-orders.php");
        exit();
    } else {
        die("Error updating order.");
    }

    $stmt->close();
    $conn->close();
} else {
    die("Invalid request method.");
}
?>
