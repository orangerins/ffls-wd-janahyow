<?php
session_start();
include('db_connection.php');

// Ensure customer is logged in
if (!isset($_SESSION['customer_id'])) {
    header("Location: login.php");
    exit();
}

$customer_id = $_SESSION['customer_id'];

// Add new order
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $wash_type = $_POST['wash_type'];
    $weight = floatval($_POST['weight']);
    $status = 'Pending';
    $date_placed = date('Y-m-d');

    // Calculate base price
    if ($wash_type === 'Wash Only') {
        $base_price = ceil($weight / 8) * 50;
    } else {
        $base_price = ceil($weight / 8) * 180;
    }

    // Inventory deduction logic
    $inventory_deduction = floor($weight / 8) * 2;

    // Handle add-ons
    $addons = $_POST['addons'] ?? [];
    $addon_total = 0;

    foreach ($addons as $addon) {
        $item_id = $addon['item_id'];
        $qty = intval($addon['quantity']);
        $price = floatval($addon['price']);

        // deduct from inventory
        $conn->query("UPDATE inventory SET quantity = quantity - $qty WHERE item_id = $item_id");

        $addon_total += $qty * $price;
    }

    // Deduct main detergent/fabric cond
    $detergent = $conn->query("SELECT item_id FROM inventory WHERE item_name='Liquid Detergent' LIMIT 1")->fetch_assoc();
    $conditioner = $conn->query("SELECT item_id FROM inventory WHERE item_name='Fabric Conditioner' LIMIT 1")->fetch_assoc();
    if ($detergent && $conditioner) {
        $conn->query("UPDATE inventory SET quantity = quantity - $inventory_deduction WHERE item_id = " . $detergent['item_id']);
        $conn->query("UPDATE inventory SET quantity = quantity - $inventory_deduction WHERE item_id = " . $conditioner['item_id']);
    }

    // Insert order
    $total_price = $base_price + $addon_total;

    $stmt = $conn->prepare("INSERT INTO laundry_request (customer_id, wash_type, weight, status, date_placed, total_price) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isdssd", $customer_id, $wash_type, $weight, $status, $date_placed, $total_price);
    $stmt->execute();

    header("Location: customer_orders.php?success=1");
    exit();
}
?>
