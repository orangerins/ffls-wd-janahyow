<?php
session_start();
include('db_connection.php');

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

if (!isset($_GET['laundry_request_id']) || !is_numeric($_GET['laundry_request_id'])) {
    die("Invalid request: ID not provided or invalid.");
}

$laundryRequestId = intval($_GET['laundry_request_id']);

$sql = "SELECT lr.*, c.first_name, c.last_name
        FROM laundry_request lr
        JOIN customer c ON lr.customer_id = c.customer_id
        WHERE lr.laundry_request_id = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error preparing statement.");
}

$stmt->bind_param("i", $laundryRequestId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    die("Order not found.");
}

$order = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Order</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f2f2f2;
        }
        .container {
            max-width: 600px;
            margin: 60px auto;
            background-color: #e0f3ff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #0077b6;
            margin-bottom: 30px;
        }
        form label {
            display: block;
            margin-top: 15px;
            color: #333;
            font-weight: 500;
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 25px;
            margin-right: 10px;
            font-size: 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            color: white;
            background-color: #0077b6;
            transition: background-color 0.3s;
        }
        .btn:hover {
            background-color: #005f8e;
        }
        .btn-secondary {
            background-color: #6c757d;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit Order #<?php echo $order['laundry_request_id']; ?></h1>
        <form action="process_edit_order.php" method="post">
            <input type="hidden" name="laundry_request_id" value="<?php echo $order['laundry_request_id']; ?>">

            <label>Wash Type:</label>
            <select name="wash_type" required>
                <option value="Wash Only" <?php if ($order['wash_type'] === 'Wash Only') echo 'selected'; ?>>Wash Only</option>
                <option value="Full Service" <?php if ($order['wash_type'] === 'Full Service') echo 'selected'; ?>>Full Service</option>
            </select>

            <label>Weight (kg):</label>
            <input type="number" step="0.01" name="weight" value="<?php echo $order['weight']; ?>" required>

            <label>Status:</label>
            <select name="status" required>
                <option value="Pending" <?php if ($order['status'] === 'Pending') echo 'selected'; ?>>Pending</option>
                <option value="Washing" <?php if ($order['status'] === 'Washing') echo 'selected'; ?>>Washing</option>
                <option value="Drying" <?php if ($order['status'] === 'Drying') echo 'selected'; ?>>Drying</option>
                <option value="Folding" <?php if ($order['status'] === 'Folding') echo 'selected'; ?>>Folding</option>
                <option value="Ready for Pick-up" <?php if ($order['status'] === 'Ready for Pick-up') echo 'selected'; ?>>Ready for Pick-up</option>
                <option value="Completed" <?php if ($order['status'] === 'Completed') echo 'selected'; ?>>Completed</option>
                <option value="Cancelled" <?php if ($order['status'] === 'Cancelled') echo 'selected'; ?>>Cancelled</option>
            </select>

            <label>Date Placed:</label>
            <input type="text" name="date_placed" value="<?php echo date('Y-m-d', strtotime($order['date_placed'])); ?>" readonly>

            <button type="submit" class="btn">Save Changes</button>
            <a href="admin-orders.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>
