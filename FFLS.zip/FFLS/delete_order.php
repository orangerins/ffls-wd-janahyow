<?php
require 'db_connection.php'; // Adjust this line as needed to connect to your DB

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'])) {
    $orderId = intval($_POST['order_id']);
    error_log("Attempting to delete order ID: $orderId"); // Log the order ID

    $stmt = $conn->prepare("DELETE FROM laundry_request WHERE laundry_request_id = ?");
    if (!$stmt) {
        error_log("Prepare failed: (" . $conn->errno . ") " . $conn->error);
        echo json_encode(["success" => false, "message" => "Database prepare error."]);
        exit;
    }

    $stmt->bind_param("i", $orderId);

    if ($stmt->execute()) {
        echo json_encode(["success" => true]);
    } else {
        error_log("Execute failed: (" . $stmt->errno . ") " . $stmt->error);
        echo json_encode(["success" => false, "message" => "Failed to delete."]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["success" => false, "message" => "Invalid request."]);
}
