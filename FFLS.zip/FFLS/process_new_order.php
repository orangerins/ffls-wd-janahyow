<?php
include('db_connection.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customerName = mysqli_real_escape_string($conn, $_POST['customer_name']);
    $washType = $_POST['wash_type'];
    $weight = floatval($_POST['weight']);
    $status = $_POST['status'];
    $datePlaced = $_POST['date_placed']; // Ensure this is received correctly
    $addonsSelected = isset($_POST['addons']) ? $_POST['addons'] : []; // Array of selected addon IDs

    $totalPayment = 0;
    $customerId = null;

    // Debugging: Output the received date
    echo "Received date: " . $datePlaced . "<br>";

    // 2. Customer Handling (same as before)
    $nameParts = explode(' ', trim($customerName));
    $firstName = isset($nameParts[0]) ? mysqli_real_escape_string($conn, $nameParts[0]) : '';
    $lastName = isset($nameParts[count($nameParts) - 1]) ? mysqli_real_escape_string($conn, $nameParts[count($nameParts) - 1]) : '';

    $checkCustomerSql = "SELECT customer_id FROM customer WHERE first_name = ? AND last_name = ?";
    $checkCustomerStmt = $conn->prepare($checkCustomerSql);
    $checkCustomerStmt->bind_param("ss", $firstName, $lastName);
    $checkCustomerStmt->execute();
    $checkCustomerResult = $checkCustomerStmt->get_result();

    if ($checkCustomerResult->num_rows > 0) {
        $customerRow = $checkCustomerResult->fetch_assoc();
        $customerId = $customerRow['customer_id'];
    } else {
        // Create new customer (same as before)
        $insertCustomerSql = "INSERT INTO customer (first_name, last_name) VALUES (?, ?)";
        $insertCustomerStmt = $conn->prepare($insertCustomerSql);
        $insertCustomerStmt->bind_param("ss", $firstName, $lastName);
        if ($insertCustomerStmt->execute()) {
            $customerId = $conn->insert_id;
        } else {
            echo "<script>alert('Error creating customer: " . $insertCustomerStmt->error . "'); window.history.back();</script>";
            exit();
        }
        $insertCustomerStmt->close();
    }
    $checkCustomerStmt->close();

    // 3. Calculate Base Price (same as before)
    if ($washType === 'Wash Only' && is_numeric($weight)) {
        $totalPayment = ceil($weight / 8) * 50;
    } elseif ($washType === 'Full Service' && is_numeric($weight)) {
        $totalPayment = ceil($weight / 8) * 180;
    }

    // 4. Add-ons (same as before)
    if (!empty($addonsSelected)) {
        $sanitizedAddons = array_map('intval', $addonsSelected);
        $addonPriceSql = "SELECT price FROM inventory WHERE item_id IN (" . implode(',', $sanitizedAddons) . ")";
        $addonPriceResult = $conn->query($addonPriceSql);
        if ($addonPriceResult && $addonPriceResult->num_rows > 0) {
            while ($addonPriceRow = $addonPriceResult->fetch_assoc()) {
                $totalPayment += $addonPriceRow['price'];
            }
        }
    }

    // 5. Date Conversion
    $mysqlDate = '';
    $dateParts = explode('/', $datePlaced); // Split by '/'
    
    // Debugging: Output the date parts
    echo "Date parts: ";
    print_r($dateParts);
    echo "<br>";

    // Check if the date parts are valid
    if (count($dateParts) === 3 && checkdate($dateParts[0], $dateParts[1], $dateParts[2])) {
        // Convert to YYYY-MM-DD format
        $mysqlDate = "{$dateParts[2]}-{$dateParts[0]}-{$dateParts[1]}";
    } else {
        // If invalid, set the date to the current date and output the error
        echo "Invalid date format or date does not exist: " . $datePlaced . "<br>";
        $mysqlDate = date('Y-m-d');  // Default to current date if invalid
    }

    // Debugging: Output the final date
    echo "Final MySQL date: " . $mysqlDate . "<br>";

    // 6. Insert Order
    $insertOrderSql = "INSERT INTO laundry_request (customer_id, date_placed, status, total_price, weight, wash_type) 
                        VALUES (?, ?, ?, ?, ?, ?)";
    $insertOrderStmt = $conn->prepare($insertOrderSql);
    $insertOrderStmt->bind_param("isssds", $customerId, $mysqlDate, $status, $totalPayment, $weight, $washType);

    if ($insertOrderStmt->execute()) {
        $orderId = $conn->insert_id; // Get the newly inserted order ID

        // 7. Subtract Liquid Detergent & Fabric Conditioner based on order and add-ons
        $detergentQuantity = 2; // Base deduction for every order
        $conditionerQuantity = 2; // Base deduction for every order

        if (!empty($addonsSelected)) {
            $addonNamesSql = "SELECT item_name FROM inventory WHERE item_id IN (" . implode(',', $sanitizedAddons) . ")";
            $addonNamesResult = $conn->query($addonNamesSql);
            if ($addonNamesResult && $addonNamesResult->num_rows > 0) {
                while ($addonNameRow = $addonNamesResult->fetch_assoc()) {
                    if (strpos($addonNameRow['item_name'], 'Liquid Detergent') !== false) {
                        $detergentQuantity++; // Increment if Liquid Detergent is an add-on
                    } elseif (strpos($addonNameRow['item_name'], 'Fabric Conditioner') !== false) {
                        $conditionerQuantity++; // Increment if Fabric Conditioner is an add-on
                    }
                }
            }
        }

        // After getting the quantity, update the database
        if ($detergentQuantity > 0 || $conditionerQuantity > 0) {
            $deductSql = "UPDATE inventory 
                            SET quantity = CASE 
                                WHEN item_name LIKE '%Liquid Detergent%' THEN quantity - ?
                                WHEN item_name LIKE '%Fabric Conditioner%' THEN quantity - ?
                                ELSE quantity
                            END
                            WHERE item_name LIKE '%Liquid Detergent%' OR item_name LIKE '%Fabric Conditioner%'";
            $deductStmt = $conn->prepare($deductSql);
            $deductStmt->bind_param("ii", $detergentQuantity, $conditionerQuantity);

            if (!$deductStmt->execute()) {
                echo "<script>alert('Order added successfully, but failed to deduct inventory: " . $deductStmt->error . "'); window.location.href='admin-orders.php';</script>";
                $deductStmt->close();
                $insertOrderStmt->close();
                $conn->close();
                exit();
            }
            $deductStmt->close();
        }

        echo "<script>alert('Order added successfully!'); window.location.href='admin-orders.php';</script>";
    } else {
        echo "<script>alert('Error adding order: " . $insertOrderStmt->error . "'); window.history.back();</script>";
    }

    $insertOrderStmt->close();
    $conn->close();
} else {
    echo "Invalid request method.";
}
?>
