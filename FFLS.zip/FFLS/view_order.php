<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'db_connection.php';

if (!isset($_GET['laundry_request_id'])) {
    http_response_code(400);
    echo "Missing laundry_request_id";
    exit;
}

$laundry_request_id = intval($_GET['laundry_request_id']); 

$query = "
SELECT lr.*, 
       c.first_name, c.middle_name, c.last_name, c.email, c.contact_number,
       i.item_name, i.category, i.price
FROM laundry_request lr
LEFT JOIN customer c ON lr.customer_id = c.customer_id
LEFT JOIN inventory i ON lr.item_id = i.item_id
WHERE lr.laundry_request_id = $laundry_request_id
";

$result = mysqli_query($conn, $query);

if (!$result) {
    http_response_code(500);
    echo "Query failed: " . mysqli_error($conn);
    exit;
}

$order = mysqli_fetch_assoc($result);

if (!$order) {
    http_response_code(404);
    echo "Order not found.";
    exit;
}
?>

<div>
    <h3>Order Details</h3>
    <p><strong>Customer:</strong> <?php echo htmlspecialchars(($order['first_name'] ?? '') . ' ' . ($order['last_name'] ?? '')); ?></p>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($order['email'] ?? 'N/A'); ?></p>
    <p><strong>Contact:</strong> <?php echo htmlspecialchars($order['contact_number'] ?? 'N/A'); ?></p>
    <p><strong>Item:</strong> <?php echo htmlspecialchars($order['item_name'] ?? 'N/A'); ?></p>
    <p><strong>Category:</strong> <?php echo htmlspecialchars($order['category'] ?? 'N/A'); ?></p>
    <p><strong>Price per Unit:</strong> ₱<?php echo htmlspecialchars($order['price'] ?? 'N/A'); ?></p>
    <p><strong>Weight:</strong> <?php echo htmlspecialchars($order['weight'] ?? '0'); ?> kg</p>
    <p><strong>Total Price:</strong> ₱<?php echo htmlspecialchars($order['total_price'] ?? '0.00'); ?></p>
    
    <p><strong>Status:</strong> <?php echo htmlspecialchars($order['status'] ?? 'Unknown'); ?></p>
    <ul>
        <li>Washing: <?php echo ($order['status'] == 'Washing' || $order['status'] == 'Drying' || $order['status'] == 'Folding' || $order['status'] == 'Ready for Pick-up' || $order['status'] == 'Completed') ? 'Completed' : 'Pending'; ?></li>
        <li>Drying: <?php echo ($order['status'] == 'Drying' || $order['status'] == 'Folding' || $order['status'] == 'Ready for Pick-up' || $order['status'] == 'Completed') ? 'Completed' : 'Pending'; ?></li>
        <li>Folding: <?php echo ($order['status'] == 'Folding' || $order['status'] == 'Ready for Pick-up' || $order['status'] == 'Completed') ? 'Completed' : 'Pending'; ?></li>
    </ul>

    <p><strong>Date Placed:</strong> <?php echo htmlspecialchars($order['date_placed'] ?? ''); ?></p>
</div>

