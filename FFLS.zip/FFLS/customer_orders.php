<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FreshFold Laundry Services</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
            text-decoration: none;
        }

        body {
            background: #f8f9fa;
            display: flex;
            flex-direction: column;
            height: 100vh;
            overflow: hidden;
        }

        header {
            background: #82b8ef;
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
            height: 60px;
        }

        .logo-menu {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        #menu-btn {
            background: none;
            border: none;
            cursor: pointer;
        }

        #menu-btn img {
            width: 25px;
            height: 25px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .user-profile img {
            width: 18px;
            height: 18px;
        }

        .sidebar {
            background: #96c7f9;
            width: 240px;
            height: 100vh;
            position: fixed;
            left: -240px;
            top: 55px;
            padding-top: 10px;
            border-right: 1px solid #ccc;
            transition: left 0.3s ease-in-out;
        }

        .sidebar.active {
            left: 0;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
        }

        .sidebar ul li img {
            width: 24px;
            height: 24px;
        }

        .sidebar ul li a {
            color: white;
            font-size: 16px;
        }

        .content {
            margin-left: 20px;
            margin-top: 60px;
            padding: 10px;
            transition: margin-left 0.3s ease-in-out;
        }

        .content.shift {
            margin-left: 260px;
        }

        .orders-controls {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            align-items: center;
        }

        #add-order-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            background-color: #82b8ef;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        #add-order-btn img {
            width: 18px;
            height: 18px;
        }

        #search-bar {
            padding: 8px;
            width: 200px;
            border-radius: 4px;
            border: 1px solid #ccc;
            font-size: 14px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ccc;
        }

        th {
            background-color: #96c7f9;
        }

        #add-order-form {
            margin-top: 20px;
            background: #f1f1f1;
            padding: 20px;
            border-radius: 8px;
            width: 400px;
            margin: 0 auto;
        }

        #add-order-form input {
            margin-bottom: 10px;
            padding: 8px;
            width: 100%;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        #add-order-form button {
            background-color: #82b8ef;
            color: white;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
            border-radius: 5px;
        }

        #cancel-order-btn {
            background-color: #f44336;
            color: white;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            margin-top: 10px;
            border-radius: 5px;
            width: 100%;
        }

        .status-pending {
            color: rgb(201, 201, 18);
            text-align: center;
            font-weight: bold;
        }

        .status-complete {
            color: green;
            text-align: center;
            font-weight: bold;
        }

        .status-ready {
            color: #82b8ef;
            text-align: center;
            font-weight: bold;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            width: 400px;
        }

        .modal-content input {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        .modal-content button {
            background-color: #82b8ef;
            color: white;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
            border-radius: 5px;
        }

        .close {
            background-color: #f44336;
            color: white;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            margin-top: 10px;
            width: 100%;
            border-radius: 5px;
        }

        .user-dropdown {
            position: relative;
            display: flex;
            align-items: center;
            gap: 5px;
            cursor: pointer;
        }

        .logout-box {
            position: absolute;
            top: 30px;
            right: 0;
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 5px;
            display: none;
            z-index: 1001;
        }

        .logout-box a {
            display: block;
            padding: 10px 20px;
            color: #165a91;
            text-decoration: none;
            font-size: 14px;
        }

        .logout-box a:hover {
            background-color: #f0f0f0;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo-menu">
            <img src="FFLSlogo.png" alt="FreshFold Logo" style="height: 50px;">
            <button id="menu-btn"><img src="m-icon.png" alt="Menu"></button>
        </div>
        <div class="user-dropdown" id="userDropdown">
            <span onclick="toggleLogout()">User</span>
            <img src="ad-icon.png" alt="Dropdown Icon" style="width: 12px; height: 12px;" onclick="toggleLogout()">
            <div class="logout-box" id="logoutBox">
                <a href="login.html">Logout</a>
            </div>
        </div>
    </header>

    <div class="sidebar" id="sidebar">
        <ul>
            <li><img src="d-icon.png" alt="Dashboard Icon"><a href="custoner_dashboard.php">Dashboard</a></li>
            <li><img src="O-icon.png" alt="Orders Icon"><a href="customer_orders.php">Orders</a></li>
            <li><img src="p-icon.png" alt="Payments Icon"><a href="customer_payment.php">Payments</a></li>
        </ul>
    </div>

    <div class="content" id="content">
        <h2>Orders</h2>
        <div class="orders-controls">
            <button id="add-order-btn"><img src="add-icon.png" alt="Add Order"> Add Order</button>
            <input type="text" id="search-bar" placeholder="Search Orders..." />
        </div>

        <table id="orders-table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Date Placed</th>
                    <th>Weight (kg)</th>
                    <th>Total Price (PHP)</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>001</td>
                    <td>2025-04-30</td>
                    <td>8</td>
                    <td>₱50.00</td>
                    <td class="status-pending">Pending</td>
                </tr>
                <tr>
                    <td>002</td>
                    <td>2025-04-29</td>
                    <td>8</td>
                    <td>₱180.00</td>
                    <td class="status-complete">Complete</td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="modal" id="orderModal">
        <div class="modal-content">
            <h3>Add New Order</h3>
            <form id="add-order-form">
                <input type="text" id="order-weight" placeholder="Weight (kg)" required>
                <input type="text" id="order-price" placeholder="Total Price (₱)" required>
                <button type="submit">Add Order</button>
                <button type="button" id="cancel-order-btn" onclick="closeOrderModal()">Cancel</button>
            </form>
        </div>
    </div>

    <script>
        const menuBtn = document.getElementById("menu-btn");
        const sidebar = document.getElementById("sidebar");
        const content = document.getElementById("content");
        const userDropdown = document.getElementById("userDropdown");
        const logoutBox = document.getElementById("logoutBox");
        const addOrderBtn = document.getElementById("add-order-btn");
        const orderModal = document.getElementById("orderModal");
        const cancelOrderBtn = document.getElementById("cancel-order-btn");

        menuBtn.addEventListener("click", () => {
            sidebar.classList.toggle("active");
            content.classList.toggle("shift");
        });

        function toggleLogout() {
            logoutBox.style.display = logoutBox.style.display === "block" ? "none" : "block";
        }

        addOrderBtn.addEventListener("click", () => {
            orderModal.style.display = "flex";
        });

        function closeOrderModal() {
            orderModal.style.display = "none";
        }

        document.getElementById("add-order-form").addEventListener("submit", (e) => {
            e.preventDefault();
            // Handle adding order logic here
            closeOrderModal();
        });

        document.getElementById("search-bar").addEventListener("input", (e) => {
            const filter = e.target.value.toLowerCase();
            const rows = document.querySelectorAll("#orders-table tbody tr");
            rows.forEach(row => {
                const cells = row.querySelectorAll("td");
                const orderId = cells[0].textContent.toLowerCase();
                if (orderId.includes(filter)) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        });
    </script>
</body>
</html>
