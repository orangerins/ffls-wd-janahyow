<?php
// Include your database connection file
include('db_connection.php');

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $customerId = 1;  // Dynamic based on logged-in customer, change as necessary
    $weight = $_POST['weight'];
    $washType = $_POST['wash_type'];
    $datePlaced = $_POST['date_placed'];
    
    // Pricing logic based on wash type and weight
    if ($washType === "wash-only") {
        $totalPrice = ($weight <= 8) ? 50 : ceil($weight / 8) * 50;
    } else if ($washType === "full-service") {
        $totalPrice = ($weight <= 8) ? 180 : ceil($weight / 8) * 180;
    }
    
    // Handle add-ons
    $addOns = 0;
    if (isset($_POST['addon-1'])) $addOns += 10; // Surf Fabric Conditioner
    if (isset($_POST['addon-2'])) $addOns += 12; // Surf Liquid Detergent
    if (isset($_POST['addon-3'])) $addOns += 15; // Downy Detergent
    
    $totalPrice += $addOns;

    // Insert order into the database
    $sql = "INSERT INTO laundry_request (customer_id, date_placed, status, total_price, weight, wash_type) VALUES (?, ?, 'Pending', ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isdis", $customerId, $datePlaced, $totalPrice, $weight, $washType);
    $stmt->execute();
    $stmt->close();
}

// Fetch orders for the logged-in customer
$customerId = 1;  // This should be dynamic based on the logged-in customer
$sql = "SELECT * FROM laundry_request WHERE customer_id = ? ORDER BY date_placed DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $customerId);
$stmt->execute();
$result = $stmt->get_result();
$orders = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FreshFold Laundry Services - Orders</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            background: #f8f9fa;
            display: flex;
            flex-direction: column;
            height: 100vh;
        }

        header {
            background: #82b8ef;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .logo-menu {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        #menu-btn {
            background: none;
            border: none;
            cursor: pointer;
        }

        #menu-btn img {
            width: 25px;
            height: 25px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .user-profile img {
            width: 18px;
            height: 18px;
        }

        .sidebar {
            background: #96c7f9;
            width: 240px;
            height: 100vh;
            position: fixed;
            left: -240px;
            top: 60px;
            padding-top: 10px;
            border-right: 1px solid #ccc;
            transition: left 0.3s ease-in-out;
        }

        .sidebar.active {
            left: 0;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
        }

        .sidebar ul li img {
            width: 24px;
            height: 24px;
        }

        .sidebar ul li a {
            color: white;
            font-size: 16px;
        }

        .content {
            margin-top: 70px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 20px;
            transition: margin-left 0.3s ease-in-out;
        }

        .content.shift {
            margin-left: 260px;
        }

        .orders-controls {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            align-items: center;
        }

        #add-order-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            background-color: #82b8ef;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        #add-order-btn img {
            width: 18px;
            height: 18px;
        }

        #search-bar {
            padding: 8px;
            width: 200px;
            border-radius: 4px;
            border: 1px solid #ccc;
            font-size: 14px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ccc;
        }

        th {
            background-color: #96c7f9;
        }

        #add-order-form {
            margin-top: 20px;
            background: #ffffff;
            padding: 25px;
            border-radius: 8px;
            width: 400px;
            margin: 0 auto;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        #add-order-form input, #add-order-form select {
            margin-bottom: 15px;
            padding: 10px;
            width: 100%;
            border-radius: 4px;
            border: 1px solid #ccc;
            font-size: 14px;
        }

        #add-order-form label {
            font-size: 14px;
            margin-bottom: 5px;
        }

        #add-order-form button {
            background-color: #82b8ef;
            color: white;
            padding: 12px 20px;
            border: none;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
            border-radius: 5px;
            font-size: 16px;
        }

        #cancel-order-btn {
            background-color: #f44336;
            color: white;
            padding: 12px 20px;
            border: none;
            cursor: pointer;
            margin-top: 10px;
            border-radius: 5px;
            width: 100%;
            font-size: 16px;
        }

        .status-pending {
            color: rgb(201, 201, 18);
            text-align: center;
            font-weight: bold;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            width: 450px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        .modal-content h3 {
            margin-bottom: 20px;
            font-size: 18px;
            font-weight: bold;
            color: #333;
        }

        .checkbox-group {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .checkbox-group label {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
        }

        .checkbox-group input {
            transform: scale(1.2);
        }

        .total-payment {
            font-size: 18px;
            font-weight: bold;
            margin-top: 10px;
        }

        .close {
            background-color: #f44336;
            color: white;
            padding: 12px 20px;
            border: none;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
            border-radius: 5px;
            font-size: 16px;
        }
         #viewOrderModal .modal-content {
            background: white;
            padding: 30px;
            border-radius: 8px;
            width: 400px;
            text-align: left;
        }

        #viewOrderModal .modal-content h3 {
            margin-bottom: 20px;
            color: #333;
        }

        #viewOrderModal .modal-content p {
            margin-bottom: 10px;
            font-size: 14px;
        }

        #close-view-btn {
            margin-top: 15px;
            background-color: #f44336;
            color: white;
            border: none;
            padding: 10px;
            width: 100%;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo-menu">
            <img src="FFLSlogo.png" alt="FreshFold Logo" style="height: 50px;">
            <button id="menu-btn"><img src="m-icon.png" alt="Menu"></button>
        </div>
        <div class="user-profile">
            <span>User</span>
        </div>
    </header>

    <div class="sidebar" id="sidebar">
        <ul>
            <li><a href="customer_dashboard.php">Dashboard</a></li>
            <li><a href="customer_orders.php">Orders</a></li>
            <li><a href="customer_payment.php">Payments</a></li>
        </ul>
    </div>

    <div class="content" id="content">
        <h2>Orders</h2>
        <div class="orders-controls">
            <button id="add-order-btn"><img src="add-icon.png" alt="Add Order"> Add Order</button>
            <input type="text" id="search-bar" placeholder="Search Orders..." />
        </div>

        <table id="orders-table">
            <thead>
                <tr>
                    <th>Date Placed</th>
                    <th>Weight (kg)</th>
                    <th>Total Price (PHP)</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="orders-body">
                <?php 
                // Check if orders exist before trying to access
                if ($orders) {
                    foreach ($orders as $order): ?>
                        <tr>
                            <td><?= isset($order['date_placed']) ? $order['date_placed'] : 'N/A' ?></td>
                            <td><?= isset($order['weight']) ? $order['weight'] : 'N/A' ?></td>
                            <td>₱<?= isset($order['total_price']) ? number_format($order['total_price'], 2) : '0.00' ?></td>
                            <td class="status-pending"><?= isset($order['status']) ? $order['status'] : 'Pending' ?></td>
                            <td><button onclick="viewOrder('<?= isset($order['date_placed']) ? $order['date_placed'] : '' ?>', '<?= isset($order['weight']) ? $order['weight'] : '' ?>', '₱<?= isset($order['total_price']) ? number_format($order['total_price'], 2) : '0.00' ?>', '<?= isset($order['wash_type']) ? $order['wash_type'] : '' ?>')">View</button></td>
                        </tr>
                    <?php endforeach;
                } else {
                    echo '<tr><td colspan="5">No orders found</td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
    <!-- View Order Modal -->
    <div id="viewOrderModal" class="modal"> <!-- Add class="modal" -->
    <div class="modal-content">
        <h3>Order Details</h3>
        <p><strong>Date Placed:</strong> <span id="view-date"></span></p>
        <p><strong>Weight:</strong> <span id="view-weight"></span> kg</p>
        <p><strong>Total Price:</strong> <span id="view-price"></span></p>
        <p><strong>Wash Type:</strong> <span id="view-type"></span></p>
        <button id="close-view-btn" onclick="closeViewModal()">Close</button>
    </div>
</div>

    <!-- Add Order Modal -->
    <div class="modal" id="orderModal">
        <div class="modal-content">
            <h3>Add New Order</h3>
            <form id="add-order-form" method="POST">
    <label for="wash-type">Wash Type:</label>
    <select id="wash-type" name="wash_type" required>
        <option value="wash-only">Wash Only (₱50 per 8 kg)</option>
        <option value="full-service">Full Service (₱180 per 8 kg)</option>
    </select>

    <label for="order-weight">Weight (kg):</label>
    <input type="number" id="order-weight" name="weight" required min="1">

    <label for="order-date">Date Placed:</label>
    <input type="date" id="order-date" name="date_placed" required>

    <label>Add-ons (Select up to 3):</label>
    <div class="checkbox-group">
        <label><input type="checkbox" id="addon-1" name="addon-1" value="surf-fabric-conditioner"> Surf Fabric Conditioner (₱10.00)</label>
        <label><input type="checkbox" id="addon-2" name="addon-2" value="surf-liquid-detergent"> Surf Liquid Detergent (₱12.00)</label>
        <label><input type="checkbox" id="addon-3" name="addon-3" value="downy-conditioner"> Downy Detergent (₱15.00)</label>
    </div>

    <div class="total-payment">Total Payment: ₱<span id="total-payment">0.00</span></div>

    <button type="submit">Add Order</button>
    <button type="button" id="cancel-order-btn" onclick="closeOrderModal()">Cancel</button>
</form>
        </div>
    </div>
   

    <script>
        // Toggle sidebar visibility
        const menuBtn = document.getElementById('menu-btn');
        const sidebar = document.getElementById('sidebar');
        const content = document.getElementById('content');

        menuBtn.addEventListener('click', () => {
            sidebar.classList.toggle('active');
            content.classList.toggle('shift');
        });
        // View order logic
        function viewOrder(date, weight, price, type) {
            document.getElementById('view-date').textContent = date;
            document.getElementById('view-weight').textContent = weight;
            document.getElementById('view-price').textContent = price;
            document.getElementById('view-type').textContent = type;
            document.getElementById('viewOrderModal').style.display = 'flex';
        }

        function closeViewModal() {
            document.getElementById('viewOrderModal').style.display = 'none';
        }

        window.onclick = function(e) {
            const modal = document.getElementById('viewOrderModal');
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        }
        // Add Order Modal
        const addOrderBtn = document.getElementById('add-order-btn');
        const orderModal = document.getElementById('orderModal');
        const cancelOrderBtn = document.getElementById('cancel-order-btn');

        // Show modal
        addOrderBtn.addEventListener('click', () => {
            orderModal.style.display = 'flex';
        });

        // Hide modal
        function closeOrderModal() {
            orderModal.style.display = 'none';
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target === orderModal) {
                orderModal.style.display = 'none';
            }
        }
        document.getElementById("order-weight").addEventListener("input", updateTotal);
        document.getElementById("wash-type").addEventListener("change", updateTotal);
        document.getElementById("addon-1").addEventListener("change", updateTotal);
        document.getElementById("addon-2").addEventListener("change", updateTotal);
        document.getElementById("addon-3").addEventListener("change", updateTotal);

        function updateTotal() {
            const weight = parseFloat(document.getElementById("order-weight").value) || 0;
            const washType = document.getElementById("wash-type").value;
            const checkboxes = document.querySelectorAll("input[type='checkbox']:checked");

            let total = 0;

            // Pricing logic for wash type and weight
            if (washType === "wash-only") {
                if (weight <= 8) {
                    total = 50; // 8kg = ₱50
                } else if (weight <= 16) {
                    total = 100; // 16kg = ₱100
                } else {
                    total = (Math.ceil(weight / 8) * 50); // More than 16kg, calculate by 8kg units
                }
            } else if (washType === "full-service") {
                if (weight <= 8) {
                    total = 180; // 8kg = ₱180
                } else if (weight <= 16) {
                    total = 360; // 16kg = ₱360
                } else {
                    total = (Math.ceil(weight / 8) * 180); // More than 16kg, calculate by 8kg units
                }
            }

            // Add-ons calculation
            checkboxes.forEach(checkbox => {
                if (checkbox.id === "addon-1") total += 10; // Surf Fabric Conditioner (₱10.00)
                if (checkbox.id === "addon-2") total += 12; // Surf Liquid Detergent (₱12.00)
                if (checkbox.id === "addon-3") total += 15; // Downy Conditioner (₱15.00)
            });

            document.getElementById("total-payment").textContent = total.toFixed(2);
        }
    </script>
</body>
</html>
